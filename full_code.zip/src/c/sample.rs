// hello world
// Path: src/c/sample.rs

fn main() {
    println!("hello world");
}